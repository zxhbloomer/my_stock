---
name: minishare
description: "AI股票助手：实时行情、盯盘监控、深度调研、选股建议、持仓管理。用户问股票价格、要盯盘、要调研、查研报公告、看持仓、问买卖建议时触发。"
user-invocable: true
---

# AI 股票助手

集行情查询、盯盘监控、深度调研、选股建议、持仓管理于一体。
基于 MiniShare 平台（Tushare Pro + AKShare 包装服务）。

文档版本：2026-04-29 更新（对齐官方手册 2026-04-27 版）

---

## 1. 初始化

首次使用时依次检查：

### 1.1 API Key

```bash
API_KEY=$(grep MINISHARE_API_KEY .env 2>/dev/null | cut -d'"' -f2)
```

没有则提示用户：

> "需要 MiniShare API Key 才能获取行情数据。请提供你的 Key，我会保存到 .env 文件。
> 还没有 Key？到 https://minishare.wmlgg.com 申请。"

用户提供后保存：
```bash
echo 'MINISHARE_API_KEY="用户的key"' >> .env
```

### 1.2 验证身份与配额

```bash
curl -s -H "X-API-Key: $API_KEY" "https://minishare.wmlgg.com/api/v1/me"
```

返回 `{username, roles, requests_per_minute, max_active_request_ips}` 等。
确认 `roles` 至少为 `user`，理解自己的 RPM 限额。

### 1.3 持仓档案

检查项目目录下是否存在 `portfolio.md`。没有则引导用户创建：

> "我来帮你建立持仓档案：
> 1. 当前持有哪些股票？（代码、数量、成本价）
> 2. 每只票的止损位是多少？（没想好我帮你算）
> 3. 在关注但还没买的票？（设触发价位监控）
> 4. 总资金大概多少？（计算仓位比例）"

按模板创建 `portfolio.md`（见第6节模板）。

---

## 2. API 全景

Base URL：`https://minishare.wmlgg.com`
认证：`X-API-Key: <key>` 头部（脚本/服务最常用）
限流：默认 50 req/min（看 `/api/v1/me` 返回 `requests_per_minute`）
缓存：响应里 `cached` / `cache_layer` 字段判断来源

### 2.1 三类接口

| 类别 | 路径前缀 | 用途 |
|------|---------|------|
| 快捷接口 | `/api/v1/{stock-basic,daily,trade-calendar,stock-company,hot-rank,hot-stocks,stock-selection/system}` | 最常用查询，参数直观 |
| 通用查询 | `/api/v1/query` (POST) | 任意 Tushare api_name，扩展性强 |
| AKShare 包装 | `/api/v1/akshare/<capability_code>` (GET) | 28个 AK 能力，含分钟K线/研报/公告等 |

### 2.2 通用查询 `/api/v1/query`（最重要）

POST 请求体：
```json
{
  "api_name": "daily",
  "params": {"ts_code": "000001.SZ", "start_date": "20260101", "end_date": "20260427"},
  "fields": ["ts_code","trade_date","open","high","low","close","vol"]
}
```

**支持的 api_name（按优先级）：**

| api_name | 用途 | 必传参数 |
|----------|------|---------|
| `daily` | 日线行情 | `ts_code`+`start_date`+`end_date`（最多366天）|
| `daily_basic` | 估值（PE/PB/换手/股息率/总市值）| `ts_code`+日期 |
| `income` | 利润表 | `ts_code` |
| `balancesheet` | 资产负债表 | `ts_code` |
| `cashflow` | 现金流量表 | `ts_code` |
| `fina_indicator` | 财务指标（净利率/ROE/yoy/OCF/营收 等） | `ts_code` |
| `top10_holders` | 十大股东 | `ts_code`+`period` |
| `top10_floatholders` | 流通股东 | `ts_code`+`period` |
| `weekly`/`monthly` | 周/月线 | `ts_code` |
| `adj_factor` | 复权因子 | `ts_code` |
| `trade_cal` | 交易日历 | `exchange` |
| `stock_company` | 上市公司资料 | `ts_code` |
| `stk_limit` | 涨跌停价 | `ts_code` |
| `suspend_d` | 停牌信息 | `ts_code` |
| `disclosure_date` | 财报披露计划 | `ts_code` |
| `stk_holdertrade` | 大股东增减持 | `ts_code` |
| `repurchase` | 回购 | `ts_code` |

### 2.3 快捷接口

| 接口 | 用途 |
|------|------|
| `GET /api/v1/me` | 看自己身份/限额 |
| `GET /api/v1/stock-basic` | 全 A 股列表（按 exchange/list_status） |
| `GET /api/v1/daily` | 日线（同 query 的 daily，参数更直观） |
| `GET /api/v1/trade-calendar` | 交易日历（本地优先） |
| `GET /api/v1/stock-company` | 上市公司资料（本地优先） |
| `GET /api/v1/hot-rank?trade_date=YYYYMMDD` | 每日热榜（同花顺+东财合并）|
| `GET /api/v1/hot-stocks?trade_date=YYYYMMDD` | 热点股票评分快照 |
| `GET /api/v1/stock-selection/system?trade_date=...` | 系统选股 |

### 2.4 AKShare 28 个能力（按模块）

**reference**（盘前/竞价）
- `pre_market_capital`、`call_auction_trades`

**company_content**（资讯类，最稳定）
- `cn_irm_qa` 董秘问答
- `announcements` 公告 ★ 高频
- `news` 新闻（可能不稳）
- `policy_library` 政策法规
- `broker_reports` 研报 ★ 高频

**market_data**（行情）
- `cn_equity_minute_history` A 股分钟历史
- `cn_equity_minute_realtime` A 股分钟实时
- `cn_equity_daily_realtime` A 股日线实时 ★ 高频
- `index_minute_history` / `index_minute_realtime` / `index_daily_realtime` 指数
- `sw_index_minute_history` / `sw_realtime_quotes` 申万行业
- `em_industry_boards` / `em_concept_boards` 东财行业/概念板块
- `em_industry_board_daily` / `em_concept_board_daily` 板块日线

**derivatives**（衍生品）
- `etf_minute_history` / `etf_minute_realtime` / `etf_daily_realtime`
- `option_minute_history`
- `convertible_bond_price_change` 可转债

**futures**（期货）
- `futures_minute_history` / `futures_minute_realtime`

**cross_border**（跨境）
- `hk_daily_history` / `hk_minute_history` / `hk_daily_realtime` / `hk_financial_reports`
- `us_daily_history` / `us_financial_reports`

### 2.5 异步导出 `/api/v1/exports`（大量历史数据）

```bash
# 创建导出任务
curl -X POST -H "X-API-Key: $KEY" -H "Content-Type: application/json" \
  "https://minishare.wmlgg.com/api/v1/exports" \
  -d '{"api_name":"daily","params":{"ts_code":"000001.SZ","start_date":"20240101","end_date":"20251231"}}'
# 返回 job_id，状态 queued

# 查询任务
GET /api/v1/exports/<job_id>          # 看状态：queued/running/succeeded/failed
POST /api/v1/exports/<job_id>/run     # 手动触发
GET /api/v1/exports/<job_id>/download # 下载 CSV
```

### 2.6 AI 辅助接口

| 接口 | 权限 | 用途 |
|------|------|------|
| `POST /api/v1/ai/question` | 普通用户 | 轻量问答（"什么是市盈率"） |
| `POST /api/v1/ai/recommend-interface` | 普通用户 | 根据意图推荐接口 |
| `POST /api/v1/ai/diagnose-error` | 普通用户 | 解释错误 payload |
| `POST /api/v1/ai/chat` | VIP/admin | 通用聊天 |
| `POST /api/v1/ai/analyze` | VIP/admin | 数据分析 |
| `POST /api/v1/ai/explain-data` | VIP/admin | 解释结构化数据 |
| `GET /api/v1/ai/status` | 普通用户 | 看 AI 是否启用 |

---

## 3. Python 调用模板（统一封装）

```python
import os, json, urllib.request, urllib.parse, time

API_KEY = ''
for line in open('.env'):
    if line.startswith('MINISHARE_API_KEY'):
        API_KEY = line.split('=',1)[1].strip().strip('"')

BASE = 'https://minishare.wmlgg.com'
SLEEP = 1.5  # 限流间隔，50/min 留 buffer

def get(path, params=None):
    """GET 请求，用于快捷接口和 AKShare 能力"""
    url = BASE + path + ('?' + urllib.parse.urlencode(params) if params else '')
    req = urllib.request.Request(url, headers={'X-API-Key': API_KEY})
    try:
        d = json.loads(urllib.request.urlopen(req, timeout=15).read())
        return (d.get('data') or {}).get('rows') or []
    except Exception as e:
        return [{'_err': str(e)}]

def post(path, body):
    """POST 请求，用于通用 query 和导出"""
    req = urllib.request.Request(BASE + path,
        data=json.dumps(body).encode(),
        headers={'X-API-Key': API_KEY, 'Content-Type': 'application/json'})
    try:
        d = json.loads(urllib.request.urlopen(req, timeout=20).read())
        return (d.get('data') or {}).get('rows') or []
    except Exception as e:
        return [{'_err': str(e)}]

# 快捷封装
def realtime(symbol):
    """A 股实时（不带后缀，如 '000728'）"""
    return get('/api/v1/akshare/cn_equity_daily_realtime', {'symbol': symbol})

def history_daily(ts_code, start, end):
    """日线历史（带后缀，如 '000728.SZ'，最多 366 天）"""
    return post('/api/v1/query', {
        'api_name': 'daily',
        'params': {'ts_code': ts_code, 'start_date': start, 'end_date': end},
        'fields': ['trade_date', 'open', 'high', 'low', 'close', 'vol']
    })

def fina(ts_code, start='20240101', end='20260501'):
    """财务指标"""
    return post('/api/v1/query', {
        'api_name': 'fina_indicator',
        'params': {'ts_code': ts_code, 'start_date': start, 'end_date': end},
        'fields': ['end_date', 'ann_date', 'netprofit_margin', 'grossprofit_margin',
                   'roe', 'q_netprofit_yoy', 'q_revenue_yoy', 'ocf_to_or', 'debt_to_assets']
    })

def valuation(ts_code, date):
    """估值（PE/PB/股息率/换手）"""
    return post('/api/v1/query', {
        'api_name': 'daily_basic',
        'params': {'ts_code': ts_code, 'trade_date': date},
        'fields': ['close', 'pe', 'pb', 'ps', 'dv_ratio', 'turnover_rate', 'volume_ratio', 'total_mv']
    })

def announcements(symbol, limit=10):
    """公告"""
    return get('/api/v1/akshare/announcements', {'symbol': symbol, 'limit': str(limit)})

def reports(symbol, limit=10):
    """研报"""
    return get('/api/v1/akshare/broker_reports', {'symbol': symbol, 'limit': str(limit)})

def auction(symbol, limit=10):
    """集合竞价"""
    return get('/api/v1/akshare/call_auction_trades', {'symbol': symbol, 'limit': str(limit)})

def holders(ts_code, period='20251231'):
    """十大股东"""
    return post('/api/v1/query', {
        'api_name': 'top10_holders',
        'params': {'ts_code': ts_code, 'period': period},
        'fields': ['holder_name', 'hold_amount', 'hold_ratio']
    })

def batch_realtime(symbols):
    """批量实时"""
    out = {}
    for s in symbols:
        r = realtime(s)
        if r and not r[0].get('_err'):
            x = r[0]
            out[s] = {**x, 'pct': round((x['close']-x['pre_close'])/x['pre_close']*100, 2) if x.get('pre_close') else 0}
        time.sleep(SLEEP)
    return out
```

---

## 4. 盯盘模式

交易日 9:25-15:05 运行。用户说"盯盘"、"开始盯"时启动。

### 4.1 心跳驱动

```bash
# 推荐：用 /loop skill
/loop 10m 检查持仓+watchlist阈值

# 或 guardian 注入
```

间隔：开盘/收盘前后5分钟，盘中平静期10-20分钟。

### 4.2 每轮检查

```python
# 1. 拉数据（持仓+watchlist+大盘）
quotes = batch_realtime(holdings_codes + watchlist_codes + ['000001', '399006'])

# 2. 阈值扫描
alerts = []
for code, q in quotes.items():
    rule = rules[code]  # 持仓: 止损价；watchlist: 买点价
    if rule['type'] == 'stop' and q['close'] < rule['price']:
        alerts.append(f"⚠️ {code} 破止损 {rule['price']}: {q['close']}")
    elif rule['type'] == 'buy' and q['close'] < rule['price']:
        alerts.append(f"✓ {code} 进买点 {rule['price']}: {q['close']}")
    if q.get('volume_ratio', 0) > 3:
        alerts.append(f"📈 {code} 量比异常 {q['volume_ratio']}")

# 3. 通知（不重复）
```

### 4.3 通知标准

**立即通知**（决策类）：
- 持仓破止损
- 急跌>5% / 急涨>8%
- watchlist 进买点
- 大盘跌>2%

**收盘汇总**（参考类）：
- 持仓涨跌>3%
- 量比>3
- 新研报/重要公告

**静默**：波动正常时

### 4.4 异动搜因

涨跌超阈值且原因不明时，按顺序拉：
```python
# 1. 公告（最近3条）
announcements(sym, limit=3)
# 2. 研报（最近3条）
reports(sym, limit=3)
# 3. 同行板块（看是个股还是板块）
batch_realtime(peer_codes)
# 4. 集合竞价（看开盘异常量比）
auction(sym, limit=3)
```

---

## 5. 深度调研模式

用户说"调研XXX"、"分析XXX"时触发。

### 5.0 一键调研（推荐用法）

使用封装脚本 `scripts/minishare_deep.py`，自动按 quick/standard/full 三档拉数据。

**命令行**：
```bash
# 标准集 (13个调用，~25秒)
python3 scripts/minishare_deep.py 000776.SZ

# 最小集 (7个调用，~12秒)
python3 scripts/minishare_deep.py 000776.SZ --tier quick

# 完整集 (18个调用，~35秒)
python3 scripts/minishare_deep.py 000776.SZ --tier full

# 同时存原始 JSON 到 data/research/
python3 scripts/minishare_deep.py 000776.SZ --save

# 只要 JSON 不要可读摘要
python3 scripts/minishare_deep.py 000776.SZ --json
```

**Python 内调用**：
```python
from scripts.minishare_deep import deep_research, summarize

data = deep_research('000776.SZ', tier='standard')
print(summarize(data))

# data 是 dict，包含所有原始 rows，自己处理：
print(data['fina_indicator'][0])     # 最近一期财务指标
print(data['top10'])                  # 十大股东
print(data['announcements'][:5])      # 近5条公告
```

**三档对应的数据点**：

| tier | 项目数 | 包含 |
|------|-------|------|
| quick | 7 | realtime + valuation + fina_indicator + announcements + reports + auction + top10 |
| standard | 13 | + income + balance + cashflow + holder_trades + margin + daily_history |
| full | 18 | + minute + float_holders + share_float + hk_hold + express |

判断该用哪档：
- 盯盘看异动 → quick
- 你问"调研XXX" → standard ★默认
- 写正式报告 / 申请重仓 → full

### 5.1 标准数据采集流程

```python
def deep_research(ts_code, sym=None):
    """ts_code 带后缀如 000728.SZ；sym 不带后缀如 000728"""
    sym = sym or ts_code.split('.')[0]
    return {
        # F级硬数据
        'realtime': realtime(sym),
        'auction': auction(sym, 10),                    # 30日竞价异常
        'valuation': valuation(ts_code, '20260427'),    # PE/PB/股息率
        'fina': fina(ts_code, '20240101', '20260501'),  # 财务指标
        'income': post('/api/v1/query', {
            'api_name': 'income',
            'params': {'ts_code': ts_code, 'start_date': '20240101', 'end_date': '20260501'},
            'fields': ['end_date', 'revenue', 'n_income_attr_p']
        }),
        'balance': post('/api/v1/query', {
            'api_name': 'balancesheet',
            'params': {'ts_code': ts_code, 'start_date': '20240101', 'end_date': '20260501'},
            'fields': ['end_date', 'total_assets', 'total_liab', 'money_cap', 'accounts_receiv', 'inventories']
        }),
        'cashflow': post('/api/v1/query', {
            'api_name': 'cashflow',
            'params': {'ts_code': ts_code, 'start_date': '20240101', 'end_date': '20260501'},
            'fields': ['end_date', 'n_cashflow_act', 'n_cashflow_inv_act']
        }),
        # 内容类
        'announcements': announcements(sym, 15),
        'reports': reports(sym, 15),
        'holders': holders(ts_code),
    }
```

### 5.2 调研报告框架

```
## [股票名称] 深度调研

### F级数据
- 当前价/涨跌幅
- PE/PB/股息率/总市值
- 资产负债率/ROE/净利率/经营现金流

### 业绩质量五项营养标签
- [ ] 非经常性损益占比 >30%？
- [ ] 经营现金流/净利润 <0.7？
- [ ] 应计比率 >10%？
- [ ] 应收账款天数同比 >30%？
- [ ] 预收款项同比 <-20%？
→ 命中 0-1: OK / 2-3: 深查 / 4-5: 回避

### 业绩同比/环比
（用 fina_indicator 拉历年 q_netprofit_yoy 看趋势）

### 估值定位
PE/PB/股息率历史分位
对比同行（拉 batch_realtime 同板块3-5只）

### 股东结构
（top10_holders 看实控人/北向/ETF 占比）

### 催化剂时间线
（announcements 拉近期重要公告）

### 风险
- 数量级：业绩 yoy / 现金流变化
- 事件：股东减持/质押/审计意见

### 结论
- 场景：底部企稳 / 趋势延续 / 事件驱动 / 不可判断
- 操作：建议 + 止损 + 目标 + R倍数
- WHY-C：如果错了，最可能因为___
```

---

## 6. 持仓管理 (portfolio.md)

### 6.1 模板

```markdown
# 我的持仓
更新时间：YYYY-MM-DD HH:MM

## 账户概览
- 总资金 / 持仓市值 / 现金 / 仓位比例

## 持仓明细
| 代码 | 名称 | 数量 | 成本价 | 最新价 | 涨跌% | 盈亏 | 仓位% | 止损位 |
|------|------|------|--------|--------|-------|------|-------|--------|

## 关注列表
| 代码 | 名称 | 当前价 | 买入区间 | 止损 | 目标 | 触发条件 |
|------|------|--------|----------|------|------|----------|

## 操作日志
| 日期 | 操作 | 代码 | 价格 | 数量 | 理由 | 结果 |

## 每日备忘
- 明日关注 / 待决策
```

### 6.2 自动维护
- 盯盘/调研后更新最新价和涨跌%
- 触发止损时文件顶部插入醒目警告
- 用户确认操作后写操作日志
- 每周末汇总盈亏

### 6.3 重要：以 portfolio.md 为单一真相源
**禁止从对话上下文猜测持仓**。任何持仓事实都先 Read 文件再说。
（避免之前"华海4/10已清仓但仍当持仓推"这类错误。）

---

## 7. 选股逻辑

### 7.1 入场过滤（5项必过）
```
□ R倍数 >= 2:1（止损距离=1R，目标≥2R）
□ 场景清晰（底部企稳/趋势延续/事件驱动）
□ 止损位明确（入场就设好的，不是过程中"感觉不对"再决定）
□ 单笔风险 < 总资金 2%
□ "如果我错了，最可能因为____" 不能空着
```

### 7.2 三大场景规则

**底部企稳**（最高胜率）
- 前期跌>15% + 缩量到均量30-50% + 守住前低 + 放量阳线反转
- 止损在前低下方3-5%（宽止损）
- 不预设时间，设 Kill Criteria

**趋势延续**（用系统替代判断）
- 价格在长期均线上方且均线向上 + 突破确认（放量+站稳2日）
- ATR 跟踪止损（2-3倍ATR），随价格上移
- 突破日量 ≥ 20日均量 × 2 才算有效放量
- ATR 突然翻倍（5日/20日 > 2）= 趋势失效，无条件离场

**事件驱动**（找定价错误，不猜方向）
- 利好后等1-2天情绪缓冲
- 放量大涨 = 分歧 = 等；缩量涨 = 共识 = 相对安全
- 利好兑现 = 凸性消亡（教训#22）

### 7.3 业绩营养标签（看到"净利+X%"先拆五项）

| 检查项 | 警戒线 | 含义 |
|--------|--------|------|
| 非经常性损益占比 | >30% | 利润质量差 |
| 经营现金流/净利润 | <0.7 | 纸面利润，没收到现金 |
| 应计比率 | >10% | 利润可能被会计放大 |
| 应收账款天数 yoy | >30% | 压货嫌疑 |
| 预收款项 yoy | <-20% | 下游需求减弱 |

A股看业绩用**扣非净利润**，不是净利润。

### 7.3.1 PEAD 四重过滤（业绩超预期挑选时必用）

看到"业绩超预期/PEAD候选"时必须四重过滤——**任一不过即排除**：

```
① 扣非/归母 ≥ 0.5    （太低=空热量主导，2026Q1隆平就是触发这条 0.77/1.66=46%）
② 净现比 ≥ 0.5        （太低=纸面利润）
③ 不是低基数扭亏     （从-0.1亿到+0.3亿增速看似+400%但实质上仍很弱）
④ 公告前20日涨幅<15% （太多=预期已被定价 凸性消亡#22）
```

四重都过的"超预期"才是真PEAD。来源：A股业绩地雷研究+康美/康得新案例。

### 7.4 风控铁律（无例外）
- 不在亏损仓位加仓（教训#63）
- 不追涨，等触发不抢跑（教训#25）
- 单票仓位 < 总资金 20%
- 止损是入场时设好的，不是过程中决定的（教训#27）
- 到止损就走，不讨论（教训#16）
- 至少保持 30% 现金（教训#38）

### 7.5 退出规则（不预设时间，预设条件）
- 止损触发 → 到价就走
- 目标达成 → 分批减仓
- 趋势衰竭 → 涨幅递减就走（#35）
- ATR止损上移触发 → 机械执行
- Kill Criteria → 写下"什么条件退出"，条件出现就走

---

## 8. 自主分析

### 8.1 收盘分析（15:05 后）
1. batch_realtime 拉持仓+关注列表
2. 更新 portfolio.md 价格盈亏
3. 检查是否触及止损
4. 检查关注列表是否进入买入区间
5. 输出当日总结

### 8.2 触发价监控
关注列表到达买入区间时：
1. 自动 deep_research
2. 过 7.1 入场过滤
3. 给买/不买建议+理由

### 8.3 盘中异动
1. 异动搜因（公告+研报+同行）
2. 判断是否影响持仓逻辑
3. 给"持有/减仓/加仓/观望"建议

---

## 9. 错误处理

接口失败先看响应里的 `category` 字段：

| category | 含义 | 处理 |
|----------|------|------|
| `auth.required` / `auth.invalid` | 凭证无效 | 重建 API Key |
| `permission.denied` | 角色无权限 | 看 `/api/v1/me` 角色 |
| `validation.invalid_request` | 参数不合法 | 对照文档检查 |
| `rate_limit.user` / `rate_limit.active_ip` | 限流 | 降低并发，等待 |
| `cold_cache_miss` | 冷缓存不允许回源 | 改查热数据 |
| `local_coverage_incomplete` | 本地历史未补齐 | 改用导出任务 或 缩小日期范围 |
| `local_coverage_out_of_range` | 超出本地边界 | 缩日期范围 |
| `upstream_failure` | 上游失败 | 稍后重试 |

HTTP 状态码：
- 400 参数错；401 鉴权错；403 无权限；404 不存在
- 409 冲突（多 IP/本地覆盖未完成）
- 422 schema 错；429 限流；503 服务不可用

---

## 10. 常用命令示例

| 用户说 | AI 做什么 |
|--------|----------|
| "看一下000728" | realtime + 简要分析 |
| "调研000728" / "深度调研" | 组合A → `python3 scripts/minishare_deep.py 000728.SZ` (standard) |
| "快速看一下000728" | `python3 scripts/minishare_deep.py 000728.SZ --tier quick` |
| "完整调研000728" | `python3 scripts/minishare_deep.py 000728.SZ --tier full --save` |
| "盯盘" | 启动盯盘心跳 |
| "我买了1000股000728，成本8.5" | 更新 portfolio.md |
| "帮我看看这票能不能买" | 入场过滤+场景判断+建议 |
| "设止损7.8" | 更新 portfolio.md 止损 |
| "今天怎么样" | 持仓当日盈亏汇总 |
| "搜一下液冷研报" | broker_reports keyword |
| "查股东" | top10_holders |
| "查PE" | daily_basic |
| "今天热点" | hot-stocks |
| "暴雷扫描" / "持仓周扫" | **组合B** 全持仓5接口扫描 |
| "看大股东减持" | stk_holdertrade(近90天) |
| "看解禁" | share_float(未来90天) |
| "看停牌" | suspend_d |
| "改名了吗" / "壳股识别" | namechange |
| "PEAD筛选" / "业绩超预期" | **组合C** 三接口筛选+四重过滤 |
| "今天有票出年报" | **组合D** disclosure_date+三表 |
| "盘后扫一下" | **组合E** daily(全市场)+热榜+板块流 |
| "akshare又崩了" | 走 minishare 降级（见11.2） |

---

## 10.5 五个高频场景组合（核心速查）

把分散的接口按"我实际场景"组合好，调用时直接套：

### 组合A：单只票深度调研（最常用 ★）
**触发**：用户说"调研XXX"、"分析XXX"、"看XXX怎么样"
**接口（9-13个）**：
```
realtime + valuation(daily_basic) + auction(call_auction_trades)
+ fina_indicator + income + balancesheet + cashflow
+ announcements(15) + broker_reports(15) + top10_holders
+ stk_holdertrade(近90天) + share_float(未来90天) + suspend_d
```
**直接用**：`python3 scripts/minishare_deep.py <ts_code> --tier standard`

### 组合B：持仓暴雷扫描（每周必跑 ★）
**触发**：用户说"暴雷扫描"、"持仓周扫"、"看看有没有风险"
**接口（每只票5个）**：
```
stk_holdertrade(近90天)  # 大股东减持 → 教训#69①
share_float(未来90天)    # 限售解禁 → 教训#69⑤
suspend_d                # 停牌识别 → 重组/被立案
repurchase               # 公司回购（维稳信号）
namechange               # 改名记录（壳股识别）
```
**输出**：每只票按"高/中/低"风险评级排序，命中2项以上=立即深查

### 组合C：PEAD候选筛选（财报季用 ★）
**触发**：用户说"PEAD"、"业绩超预期"、"财报季筛选"
**接口（3个）**：
```
fina_indicator(period=最新季度)  # 拿增速+扣非
daily_basic(trade_date=今天)     # 拿PE/PB/换手
disclosure_date(end_date=本月)   # 拿披露日
```
**过滤**：四重过滤（见7.3.1节）—— 任一不过即排除

### 组合D：财报季业绩验证（4月/8月/10月集中用）
**触发**：用户说"今天有票出年报/季报"、"业绩验证"
**接口（4个）**：
```
disclosure_date(本周)            # 谁今天发
fina_indicator(period=本期)      # 增速核查
income+balancesheet+cashflow    # 三表组合
announcements(limit=5)           # 当日实时公告
```

### 组合E：每日盘后扫描（15:30-17:00 跑）
**触发**：用户说"盘后扫一下"、"今天市场怎么样"
**接口（4-5个）**：
```
daily(trade_date=今天)           # 全市场单日（一次性返回）
daily_basic(trade_date=今天)     # 全市场估值
hot-rank(trade_date=今天)        # 热榜
em_industry_boards               # 行业资金流
em_concept_boards                # 概念资金流
```

---

## 11. 数据获取优先级

### 11.1 通道排序
```
1. MiniShare API（优先）
   - 行情：cn_equity_daily_realtime / 历史 daily
   - 财务：fina_indicator / income / balancesheet / cashflow
   - 估值：daily_basic
   - 内容：announcements / broker_reports / cn_irm_qa
   - 股东：top10_holders / top10_floatholders / stk_holdertrade
   - 板块：em_industry_boards / em_concept_boards

2. akshare 直连（备用 / 已有脚本依赖）
   - scripts/data_fetcher.py 等老脚本仍走 akshare
   - 与 minishare 形成双通道

3. WebSearch（API 缺失才用）
   - 突发新闻 / 政策深度解读
   - 港股财报细项 / 美股深度
   - 行业格局 / 竞品分析

4. 两者结合 → 调研用 API 拿结构化数据，WebSearch 补定性分析
```

### 11.2 双通道降级（akshare 故障兜底）

实战经验：akshare 直连有概率出现 `RemoteDisconnected` 或卡死。判断+切换流程：

```python
# 检测条件（任一成立=降级到minishare）：
# 1. akshare 调用连续 2 次报 ConnectionError/RemoteDisconnected
# 2. akshare 调用超时 >10 秒
# 3. akshare 返回 Empty DataFrame 但 minishare 正常

# 降级模板：
try:
    quote = ak.stock_bid_ask_em(symbol='601127')
    if quote.empty: raise Exception('akshare empty')
except Exception:
    # 切到 minishare
    quote = realtime('601127')  # cn_equity_daily_realtime
```

**注意**：minishare 实时接口走 Tushare 上游，**共享 20 次/分钟回源限流**（即使你账号QPM=50）。批量盯盘时一轮5只票=5次，3-4轮就到上限。错峰策略：
- 每5分钟一轮，不是每1分钟
- 优先用 historical `daily(trade_date=昨天)` 看趋势，盘中只在关键时点拉实时

---

## 12. 注意事项

- **限流**：默认 50/min（看 `/api/v1/me` 实际配额）。批量查询 sleep 1.5-2 秒
- **ts_code 格式**：通用查询用 `000001.SZ` / `600000.SH`；AKShare 部分接口用 `000001`（不带后缀）
- **历史日线 query**：必带 `ts_code`，单次最多 366 天
- **大量历史数据**：用 `/api/v1/exports` 异步任务，不要长时间阻塞同步接口
- **本地缓存**：`cache_layer=local` 是本地表，`source` 是上游回源
- **新闻接口**：中文 keyword 需 URL 编码，结果不稳定时用 WebSearch
- **数据不是建议**：所有分析仅供参考，决策由用户做
- **持仓真相源**：以 portfolio.md 为准，禁止从上下文猜
- **详细规则**：references/ 目录下还有选股规则、业绩分析、风控规则的展开
