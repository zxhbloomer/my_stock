# MiniShare 行情数据 API 接口文档

> **Base URL:** `https://minishare.wmlgg.com/api/v1/akshare`
>
> **认证方式:** 请求头携带 `X-API-Key: 你的Key`

---

## 一、基础市场数据

### 1.1 A股分钟实时 `cn_equity_minute_realtime`

查询 A 股实时分钟行情，适合盯盘和盘中监控。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `period` | K线周期 | `1min` |
| `limit` | 返回条数 | `50` |

```
GET /cn_equity_minute_realtime?symbol=000001&period=1min&limit=50
```

### 1.2 A股历史分钟 `cn_equity_minute_history`

查询 A 股历史分钟行情，适合分钟级回看和量价分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /cn_equity_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 1.3 A股日线实时 `cn_equity_daily_realtime`

查询 A 股实时日线行情，适合看当日行情快照。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `fields` | 指定字段 | `open,high,low,close,volume` |

```
GET /cn_equity_daily_realtime?symbol=000001&trade_date=20260410&fields=open,high,low,close,volume
```

### 1.4 申万实时行情 `sw_realtime_quotes`

查询申万行业实时行情，适合快速看行业当前表现。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 行业代码 | `000001` |
| `period` | K线周期 | `1min` |
| `limit` | 返回条数 | `50` |

```
GET /sw_realtime_quotes?symbol=000001&period=1min&limit=50
```

### 1.5 申万指数分钟 `sw_index_minute_history`

查询申万行业指数历史分钟行情，适合看行业盘中走势。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 行业代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /sw_index_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 1.6 指数分钟实时 `index_minute_realtime`

查询指数实时分钟行情，适合盯盘和盘中监控。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 指数代码 | `000001` |
| `period` | K线周期 | `1min` |
| `limit` | 返回条数 | `50` |

```
GET /index_minute_realtime?symbol=000001&period=1min&limit=50
```

### 1.7 指数历史分钟 `index_minute_history`

查询指数历史分钟行情，适合做盘中走势回看。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 指数代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /index_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 1.8 指数日线实时 `index_daily_realtime`

查询指数实时日线行情，适合看当日指数表现。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 指数代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `fields` | 指定字段 | `open,high,low,close,volume` |

```
GET /index_daily_realtime?symbol=000001&trade_date=20260410&fields=open,high,low,close,volume
```

---

## 二、衍生品与基金

### 2.1 可转债价格变动 `convertible_bond_price_change`

查询可转债价格变动数据，适合看盘中波动和异动情况。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 转债代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `limit` | 返回条数 | `50` |

```
GET /convertible_bond_price_change?symbol=000001&trade_date=20260410&limit=50
```

### 2.2 期权历史分钟 `option_minute_history`

查询期权历史分钟行情，适合做分钟级复盘分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 期权代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /option_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 2.3 ETF分钟实时 `etf_minute_realtime`

查询 ETF 实时分钟行情，适合盯盘和盘中监控。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | ETF代码 | `000001` |
| `period` | K线周期 | `1min` |
| `limit` | 返回条数 | `50` |

```
GET /etf_minute_realtime?symbol=000001&period=1min&limit=50
```

### 2.4 ETF历史分钟 `etf_minute_history`

查询 ETF 历史分钟行情，适合做分钟级复盘分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | ETF代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /etf_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 2.5 ETF日线实时 `etf_daily_realtime`

查询 ETF 实时日线行情，适合看当日基金表现。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | ETF代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `fields` | 指定字段 | `open,high,low,close,volume` |

```
GET /etf_daily_realtime?symbol=000001&trade_date=20260410&fields=open,high,low,close,volume
```

---

## 三、期货数据

### 3.1 期货历史分钟 `futures_minute_history`

查询期货历史分钟行情，适合做历史回看和分钟级分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 期货代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /futures_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 3.2 期货实时分钟 `futures_minute_realtime`

查询期货实时分钟行情，适合盯盘和盘中监控。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 期货代码 | `000001` |
| `period` | K线周期 | `1min` |
| `limit` | 返回条数 | `50` |

```
GET /futures_minute_realtime?symbol=000001&period=1min&limit=50
```

---

## 四、跨境市场

### 4.1 港股财报 `hk_financial_reports`

查询港股财报数据，适合看公司财务披露内容。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 港股代码 | `000001` |
| `report_period` | 报告期 | `2025Q4` |
| `statement_type` | 报表类型 | `income` |
| `limit` | 返回条数 | `50` |

```
GET /hk_financial_reports?symbol=000001&report_period=2025Q4&statement_type=income&limit=50
```

### 4.2 港股历史分钟 `hk_minute_history`

查询港股历史分钟行情，适合做分钟级复盘分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 港股代码 | `000001` |
| `start_time` | 开始时间 | `2026-04-11 09:30:00` |
| `end_time` | 结束时间 | `2026-04-11 15:00:00` |
| `period` | K线周期 | `1min` |
| `adjust` | 复权方式 | `qfq` |

```
GET /hk_minute_history?symbol=000001&start_time=2026-04-11 09:30:00&end_time=2026-04-11 15:00:00&period=1min&adjust=qfq
```

### 4.3 港股历史日线 `hk_daily_history`

查询港股历史日线行情，适合做区间走势和复盘分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 港股代码 | `000001` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `adjust` | 复权方式 | `qfq` |
| `fields` | 指定字段 | `open,high,low,close,volume` |

```
GET /hk_daily_history?symbol=000001&start_date=20260401&end_date=20260410&adjust=qfq&fields=open,high,low,close,volume
```

### 4.4 港股实时日线 `hk_daily_realtime`

查询港股实时日线行情，适合看当日行情快照。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 港股代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `fields` | 指定字段 | `open,high,low,close,volume` |

```
GET /hk_daily_realtime?symbol=000001&trade_date=20260410&fields=open,high,low,close,volume
```

### 4.5 美股财报 `us_financial_reports`

查询美股财报数据，适合看公司财务披露内容。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 美股代码 | `000001` |
| `report_period` | 报告期 | `2025Q4` |
| `statement_type` | 报表类型 | `income` |
| `limit` | 返回条数 | `50` |

```
GET /us_financial_reports?symbol=000001&report_period=2025Q4&statement_type=income&limit=50
```

### 4.6 美股历史日线 `us_daily_history`

查询美股历史日线行情，适合做区间走势和复盘分析。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 美股代码 | `000001` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `adjust` | 复权方式 | `qfq` |
| `fields` | 指定字段 | `open,high,low,close,volume` |

```
GET /us_daily_history?symbol=000001&start_date=20260401&end_date=20260410&adjust=qfq&fields=open,high,low,close,volume
```

---

## 五、公司与资讯

### 5.1 券商研报 `broker_reports`

按股票、机构或关键词检索券商研报。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `keyword` | 关键词 | `机器人` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `limit` | 返回条数 | `50` |
| `page` | 页码 | `1` |

```
GET /broker_reports?symbol=000001&keyword=机器人&start_date=20260401&end_date=20260410&limit=50&page=1
```

### 5.2 公告数据 `announcements`

按股票、关键词或时间范围检索上市公司公告。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `keyword` | 关键词 | `机器人` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `limit` | 返回条数 | `50` |
| `page` | 页码 | `1` |

```
GET /announcements?symbol=000001&keyword=机器人&start_date=20260401&end_date=20260410&limit=50&page=1
```

### 5.3 沪深董秘问答 `cn_irm_qa`

查询沪深上市公司董秘互动问答内容。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `keyword` | 关键词 | `机器人` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `limit` | 返回条数 | `50` |
| `page` | 页码 | `1` |

```
GET /cn_irm_qa?symbol=000001&keyword=机器人&start_date=20260401&end_date=20260410&limit=50&page=1
```

### 5.4 新闻资讯 `news`

查询市场新闻资讯，适合跟踪公司或主题相关新闻。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `keyword` | 关键词 | `机器人` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `limit` | 返回条数 | `50` |
| `page` | 页码 | `1` |

```
GET /news?symbol=000001&keyword=机器人&start_date=20260401&end_date=20260410&limit=50&page=1
```

### 5.5 政策法规库 `policy_library`

按主题或关键词检索政策法规信息。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 相关代码 | `000001` |
| `keyword` | 关键词 | `机器人` |
| `start_date` | 开始日期 | `20260401` |
| `end_date` | 结束日期 | `20260410` |
| `limit` | 返回条数 | `50` |
| `page` | 页码 | `1` |

```
GET /policy_library?symbol=000001&keyword=机器人&start_date=20260401&end_date=20260410&limit=50&page=1
```

---

## 六、基础信息

### 6.1 集合竞价成交 `call_auction_trades`

查询 A 股集合竞价阶段的成交数据，适合看开盘前的撮合情况。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `limit` | 返回条数 | `50` |

```
GET /call_auction_trades?symbol=000001&trade_date=20260410&limit=50
```

### 6.2 盘前股本 `pre_market_capital`

查询 A 股盘前股本相关数据，适合做开盘前基础资料核对。

| 参数 | 说明 | 示例 |
|------|------|------|
| `symbol` | 股票代码 | `000001` |
| `trade_date` | 交易日期 | `20260410` |
| `limit` | 返回条数 | `50` |

```
GET /pre_market_capital?symbol=000001&trade_date=20260410&limit=50
```

---

## 接口速览

| # | 功能ID | 分类 | 市场 | 频率 |
|---|--------|------|------|------|
| 1 | `cn_equity_minute_realtime` | 分钟实时 | A股 | 每分钟 |
| 2 | `cn_equity_minute_history` | 分钟历史 | A股 | 每分钟 |
| 3 | `cn_equity_daily_realtime` | 实时日线 | A股 | 每分钟 |
| 4 | `sw_realtime_quotes` | 实时行情 | 申万行业 | 每分钟 |
| 5 | `sw_index_minute_history` | 分钟历史 | 申万行业 | 每分钟 |
| 6 | `index_minute_realtime` | 分钟实时 | 指数 | 每分钟 |
| 7 | `index_minute_history` | 分钟历史 | 指数 | 每分钟 |
| 8 | `index_daily_realtime` | 实时日线 | 指数 | 每分钟 |
| 9 | `convertible_bond_price_change` | 可转债 | A股 | 每分钟 |
| 10 | `option_minute_history` | 分钟历史 | 期权 | 每分钟 |
| 11 | `etf_minute_realtime` | 分钟实时 | ETF | 每分钟 |
| 12 | `etf_minute_history` | 分钟历史 | ETF | 每分钟 |
| 13 | `etf_daily_realtime` | 实时日线 | ETF | 每分钟 |
| 14 | `futures_minute_history` | 分钟历史 | 期货 | 每分钟 |
| 15 | `futures_minute_realtime` | 分钟实时 | 期货 | 每分钟 |
| 16 | `hk_financial_reports` | 财报 | 港股 | 每分钟 |
| 17 | `hk_minute_history` | 分钟历史 | 港股 | 每分钟 |
| 18 | `hk_daily_history` | 日线历史 | 港股 | 每分钟 |
| 19 | `hk_daily_realtime` | 实时日线 | 港股 | 每分钟 |
| 20 | `us_financial_reports` | 财报 | 美股 | 每分钟 |
| 21 | `us_daily_history` | 日线历史 | 美股 | 每分钟 |
| 22 | `broker_reports` | 研报 | 全市场 | 每分钟 |
| 23 | `announcements` | 公告披露 | 全市场 | 每分钟 |
| 24 | `cn_irm_qa` | 互动问答 | A股 | 每分钟 |
| 25 | `news` | 资讯 | 全市场 | 每分钟 |
| 26 | `policy_library` | 政策法规 | 宏观 | 每分钟 |
| 27 | `call_auction_trades` | 盘前行情 | A股 | 每分钟 |
| 28 | `pre_market_capital` | 基础资料 | A股 | 每分钟 |
