# MiniShare API 接口测试报告

**测试时间**: 2026-04-13
**Base URL**: `https://minishare.wmlgg.com/api/v1/akshare`
**认证**: X-API-Key
**限流**: 30次/分钟 (429错误)

---

## 汇总表

| # | 接口 | 状态 | HTTP | 行数 | 关键字段 | 备注 |
|---|------|------|------|------|----------|------|
| 1 | cn_equity_minute_realtime | **可用** | 200 | 1 | ts_code,freq,time,open,close,high,low,vol,amount | 000728返回最新1min数据,close=7.8 |
| 2 | cn_equity_minute_history | **可用** | 200 | 31 | ts_code,trade_time,close,open,high,low,vol,amount | 000728当日30min历史正常 |
| 3 | cn_equity_daily_realtime | **可用** | 200 | 1 | ts_code,name,pre_close,high,open,low,close,vol,amount | 000728日线快照,name=国元证券 |
| 4 | sw_realtime_quotes | **可用** | 200 | 1 | trade_time,ts_code,name,close,pre_close,high,low,amount | 801780银行指数,close=3971.294 |
| 5 | sw_index_minute_history | **可用** | 200 | 1205 | ts_code,trade_time,open,close,high,low,amount | 801780返回大量历史分钟(无需指定时间范围) |
| 6 | index_minute_realtime | **可用** | 200 | 1 | code,freq,time,open,close,high,low,vol,amount | 上证000001,close=3988.558 |
| 7 | index_minute_history | **可用** | 200 | 1205 | ts_code,trade_time,close,open,high,low,vol,amount | 000001返回大量历史分钟 |
| 8 | index_daily_realtime | **可用** | 200 | 1 | ts_code,name,trade_time,close,pre_close,high,open,low,vol,amount | 上证指数日线快照 |
| 9 | convertible_bond_price_change | **接口通但无数据** | 200 | 0 | ts_code,bond_short_name,publish_date,change_date,convert_price_initial,convertprice_bef,convertprice_aft | 113009/128121均返回空,可能是转股价变动历史表而非实时行情 |
| 10 | option_minute_history | **接口通但无数据** | 200 | 0 | ts_code,trade_time,open,close,high,low,vol,amount,oi | 多个期权代码均返回空,可能代码格式不对或数据未覆盖 |
| 11 | etf_minute_realtime | **可用** | 200 | 1 | 同A股分钟格式 | **注意: symbol需带后缀(510050.SH)**, 不带后缀返回502 |
| 12 | etf_minute_history | **可用** | 200 | 241 | ts_code,trade_time,close,open,high,low,vol,amount | 510050.SH全天241条分钟数据; 不带后缀时510050返回0行 |
| 13 | etf_daily_realtime | **可用** | 200 | 1 | amount,close,high,low,name,open,pre_close,ts_code,vol | **注意: symbol需带后缀**, 159915.SZ可用, 510050.SH返回0行(可能非交易时间) |
| 14 | futures_minute_history | **接口通但无数据** | 200 | 0 | ts_code,trade_time,open,close,high,low,vol,amount,oi | IF2604/IF0/AU2506均返回空 |
| 15 | futures_minute_realtime | **接口通但无数据** | 200 | 0 | code,freq,time,open,close,high,low,vol,amount,oi | IF2604/IF0/AU2506均返回空 |
| 16 | hk_financial_reports | **接口通但无数据** | 200 | 0 | ts_code,end_date,name,ind_name,ind_value | 00700多种参数组合均返回空; balance类型返回422 |
| 17 | hk_minute_history | **可用** | 200 | 31 | ts_code,trade_time,open,close,high,low,vol,amount | 00700.HK分钟数据完整,open=498.4 |
| 18 | hk_daily_history | **可用** | 200 | 5 | ts_code,trade_date,open,high,low,close,pre_close,change,pct_chg,vol,amount | 00700.HK 4/1-4/10五个交易日 |
| 19 | hk_daily_realtime | **可用** | 200 | 1 | ts_code,pre_close,close,high,open,low,vol,amount | 00700.HK close=490.0 |
| 20 | us_financial_reports | **可用** | 200 | 5 | ts_code,end_date,ind_type,name,ind_name,ind_value,report_type | AAPL不指定period时返回5条(Q1数据); 指定2024Q4/2025Q4返回空 |
| 21 | us_daily_history | **可用** | 200 | 7 | ts_code,trade_date,close,open,high,low,pre_close,pct_change,vol,amount,vwap | AAPL 4/1-4/10七个交易日,含vwap |
| 22 | broker_reports | **可用** | 200 | 3 | trade_date,title,report_type,author,name,ts_code,inst_csname,ind_name,url | 000728返回山西证券/太平洋/海通国际研报,含PDF下载链接 |
| 23 | announcements | **可用** | 200 | 3 | ann_date,ts_code,name,title,url | 000728最新公告(2026-04-10科创债公告) |
| 24 | cn_irm_qa | **可用** | 200 | 3 | ts_code,name,trade_date,q,a,pub_time | 000728董秘问答,含问答全文(年报披露日期等) |
| 25 | news | **部分可用** | 200 | 3 | datetime,content,title | keyword=AI可返回3条,但keyword=国元证券返回0条; 有条title为None |
| 26 | policy_library | **不可用** | 501 | N/A | N/A | 返回"暂未找到稳定可用的Tushare Pro对应接口" |
| 27 | call_auction_trades | **可用** | 200 | 1 | ts_code,trade_date,vol,price,amount,pre_close,float_share | 000728集合竞价: price=7.72, vol=2790008 |
| 28 | pre_market_capital | **可用** | 200 | 482 | trade_date,ts_code,total_share,float_share,pre_close,up_limit,down_limit | 000728返回482条历史股本数据 |

---

## 分类统计

### 完全可用 (18个)
1, 2, 3, 4, 5, 6, 7, 8, 17, 18, 19, 21, 22, 23, 24, 27, 28, 20(部分)

### 可用但有限制 (3个)
- **11 etf_minute_realtime**: symbol必须带交易所后缀(.SH/.SZ)
- **12 etf_minute_history**: symbol必须带交易所后缀
- **13 etf_daily_realtime**: symbol必须带交易所后缀
- **25 news**: keyword搜索部分有效,部分title为None

### 接口通但无数据 (5个)
- **9 convertible_bond_price_change**: 可能仅记录转股价调整事件,非实时行情
- **10 option_minute_history**: 期权代码格式不明确
- **14 futures_minute_history**: 期货代码格式不明确或数据未覆盖
- **15 futures_minute_realtime**: 同上
- **16 hk_financial_reports**: 港股财报数据未接入

### 不可用 (1个)
- **26 policy_library**: 后端明确表示"暂未找到稳定可用的Tushare Pro对应接口"

---

## 关键发现

1. **限流**: 30次/分钟,密集调用时需注意间隔
2. **ETF代码格式**: etf系列接口要求symbol带交易所后缀(如510050.SH),A股接口不需要 -- 这是一个不一致
3. **期货/期权**: 虽然接口路由存在且返回200,但实际数据为空,可能上游Tushare未授权或代码映射问题
4. **港股财报**: 接口框架存在但数据为空; 美股财报不指定period时可以返回数据
5. **A股核心接口全部可用**: 分钟实时/历史、日线实时、指数、申万行业、研报、公告、董秘问答、集合竞价、盘前股本全部正常
6. **数据字段丰富**: 所有接口返回标准化JSON,含row_count/columns/rows结构,便于程序化处理
7. **sw_index_minute_history和index_minute_history**: 不指定时间范围时返回约1205条(约5个交易日),数据量大

## 实际可用于盯盘/分析的核心接口

| 用途 | 推荐接口 | 说明 |
|------|----------|------|
| A股实时盯盘 | cn_equity_minute_realtime | 最新1min K线 |
| A股分钟回看 | cn_equity_minute_history | 指定时间段分钟数据 |
| A股日线快照 | cn_equity_daily_realtime | 当日OHLCV |
| 大盘指数 | index_minute_realtime / index_daily_realtime | 上证/深证指数 |
| 行业板块 | sw_realtime_quotes / sw_index_minute_history | 申万行业实时 |
| 港股行情 | hk_minute_history / hk_daily_history / hk_daily_realtime | 全部可用 |
| 美股日线 | us_daily_history | AAPL等美股历史日线 |
| ETF行情 | etf_minute_realtime(需.SH/.SZ后缀) | ETF实时/历史 |
| 研报/公告 | broker_reports / announcements | 含PDF下载链接 |
| 董秘问答 | cn_irm_qa | 含完整Q&A文本 |
| 集合竞价 | call_auction_trades | 开盘前竞价数据 |
| 股本数据 | pre_market_capital | 历史股本/涨跌停价 |
